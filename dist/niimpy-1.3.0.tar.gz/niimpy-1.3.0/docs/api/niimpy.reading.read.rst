niimpy.reading.read module
==========================

.. automodule:: niimpy.reading.read
   :members:
   :undoc-members:
   :show-inheritance:
