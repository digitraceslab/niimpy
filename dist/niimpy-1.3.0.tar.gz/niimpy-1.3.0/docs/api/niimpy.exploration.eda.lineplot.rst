niimpy.exploration.eda.lineplot module
======================================

.. automodule:: niimpy.exploration.eda.lineplot
   :members:
   :undoc-members:
   :show-inheritance:
