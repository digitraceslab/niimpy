niimpy.exploration.setup\_dataframe module
==========================================

.. automodule:: niimpy.exploration.setup_dataframe
   :members:
   :undoc-members:
   :show-inheritance:
