niimpy.analysis.rhythms module
==============================

.. automodule:: niimpy.analysis.rhythms
   :members:
   :undoc-members:
   :show-inheritance:
