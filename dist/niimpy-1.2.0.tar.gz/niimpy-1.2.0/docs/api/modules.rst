niimpy API docs
===============

This section provides function reference for Niimpy. Please refer to the user guide for further details on the function usage.

.. toctree::
   :maxdepth: 4

   niimpy
