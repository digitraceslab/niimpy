niimpy package
==============

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   niimpy.analysis
   niimpy.config
   niimpy.exploration
   niimpy.preprocessing
   niimpy.reading

Module contents
---------------

.. automodule:: niimpy
   :members:
   :undoc-members:
   :show-inheritance:
