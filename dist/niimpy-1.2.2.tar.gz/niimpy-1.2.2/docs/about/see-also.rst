See also
========

List of references:

- Aledavood, Talayeh, et al. "Data collection for mental health studies through digital platforms: requirements and design of a prototype." JMIR research protocols 6.6 (2017): e6919. doi:10.2196/resprot.6919
- Triana, Ana María, et al. "Mobile Monitoring of Mood (MoMo-Mood) pilot: A longitudinal, multi-sensor digital phenotyping study of patients with major depressive disorder and healthy controls." medRxiv (2020)
