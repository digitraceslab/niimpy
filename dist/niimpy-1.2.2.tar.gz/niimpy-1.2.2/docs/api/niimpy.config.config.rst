niimpy.config.config module
===========================

.. automodule:: niimpy.config.config
   :members:
   :undoc-members:
   :show-inheritance:
