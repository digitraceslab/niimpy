niimpy.exploration package
==========================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   niimpy.exploration.eda

Submodules
----------

.. toctree::
   :maxdepth: 4

   niimpy.exploration.missingness
   niimpy.exploration.setup_dataframe

Module contents
---------------

.. automodule:: niimpy.exploration
   :members:
   :undoc-members:
   :show-inheritance:
