niimpy.exploration.eda package
==============================

Submodules
----------

.. toctree::
   :maxdepth: 4

   niimpy.exploration.eda.categorical
   niimpy.exploration.eda.countplot
   niimpy.exploration.eda.lineplot
   niimpy.exploration.eda.missingness
   niimpy.exploration.eda.punchcard

Module contents
---------------

.. automodule:: niimpy.exploration.eda
   :members:
   :undoc-members:
   :show-inheritance:
