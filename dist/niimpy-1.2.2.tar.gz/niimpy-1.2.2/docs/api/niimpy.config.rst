niimpy.config package
=====================

Submodules
----------

.. toctree::
   :maxdepth: 4

   niimpy.config.config

Module contents
---------------

.. automodule:: niimpy.config
   :members:
   :undoc-members:
   :show-inheritance:
