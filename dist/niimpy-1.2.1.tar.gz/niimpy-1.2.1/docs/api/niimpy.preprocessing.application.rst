niimpy.preprocessing.application module
=======================================

.. automodule:: niimpy.preprocessing.application
   :members:
   :undoc-members:
   :show-inheritance:
