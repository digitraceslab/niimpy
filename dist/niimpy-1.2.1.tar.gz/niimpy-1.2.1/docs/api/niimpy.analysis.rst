niimpy.analysis package
=======================

Submodules
----------

.. toctree::
   :maxdepth: 4

   niimpy.analysis.rhythms

Module contents
---------------

.. automodule:: niimpy.analysis
   :members:
   :undoc-members:
   :show-inheritance:
