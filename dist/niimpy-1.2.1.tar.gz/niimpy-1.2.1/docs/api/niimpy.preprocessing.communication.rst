niimpy.preprocessing.communication module
=========================================

.. automodule:: niimpy.preprocessing.communication
   :members:
   :undoc-members:
   :show-inheritance:
