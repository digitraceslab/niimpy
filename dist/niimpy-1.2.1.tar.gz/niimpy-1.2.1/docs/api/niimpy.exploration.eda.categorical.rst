niimpy.exploration.eda.categorical module
=========================================

.. automodule:: niimpy.exploration.eda.categorical
   :members:
   :undoc-members:
   :show-inheritance:
