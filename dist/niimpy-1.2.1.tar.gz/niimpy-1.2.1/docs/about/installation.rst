Installation
============

Niimpy is a normal Python package to install. It is not currently available on PyPi, so you can install it manually from github repository:

.. code-block:: bash

    pip install niimpy

Note: only supports Python 3 (tested on 3.6. and above).


