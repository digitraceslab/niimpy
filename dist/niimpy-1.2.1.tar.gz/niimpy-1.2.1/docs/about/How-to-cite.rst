How to cite
===========

Ikäheimonen, A., Triana, A. M., Luong, N., Ziaei, A., Rantaharju, J., Darst, R., & Aledavood, T. (2023). Niimpy: a toolbox for behavioral data analysis. SoftwareX, 23, 101472.

bibtex format:

@article{niimpy,

         title = {Niimpy: A toolbox for behavioral data analysis},
         journal = {SoftwareX},
         volume = {23},
         pages = {101472},
         year = {2023},
         issn = {2352-7110},
         doi = {https://doi.org/10.1016/j.softx.2023.101472},
         url = {https://www.sciencedirect.com/science/article/pii/S2352711023001681},
         author = {Arsi Ikäheimonen and Ana M. Triana and Nguyen Luong and Amirmohammad Ziaei and Jarno Rantaharju and Richard Darst and Talayeh Aledavood},
         keywords = {Data analysis toolbox, Digital behavioral studies, Mobile sensing, Python package},
         }
